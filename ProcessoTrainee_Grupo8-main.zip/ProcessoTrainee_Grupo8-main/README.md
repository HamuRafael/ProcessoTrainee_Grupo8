# ProcessoTrainee_Grupo8
Projeto introdutório da Empresa Júnior de Computação da UnB (CJR). Consiste em fazer um tipo de uma réplica do Twitter
