function redirectToPage(destination){
    window.location.href=destination
}
